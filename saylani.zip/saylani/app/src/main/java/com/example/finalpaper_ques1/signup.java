package com.example.finalpaper_ques1;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.util.Range;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

public class signup extends AppCompatActivity {

private AwesomeValidation awesomeValidation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        final EditText userName = (EditText) findViewById(R.id.name);
        final EditText password = (EditText) findViewById(R.id.pass);
        final EditText email = (EditText) findViewById(R.id.email);
        Button btnRegister = (Button) findViewById(R.id.submitform7);





        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast =  Toast.makeText(getApplicationContext(),"Registered",Toast.LENGTH_SHORT);
                toast.show();
                //adding validation to edittexts

                SharedPreferences preferences = getSharedPreferences("MYPREFS",MODE_PRIVATE);
                String newUser  = userName.getText().toString();
                String newPassword = password.getText().toString();
                String newEmail = email.getText().toString();

                SharedPreferences.Editor editor = preferences.edit();

                //stores 3 new instances of sharedprefs. Both the user and password's keys are the same as the input.
                //Must be done this way because sharedprefs is stupid and inefficient. You cannot store Arrays easily
                //so I use strings instead.
                editor.putString(newUser,newUser);
                editor.commit();
                editor.putString(newPassword, newPassword);
                editor.commit();
                editor.putString(newUser + newPassword + "data", newUser + " Good To See You" + "You're logged In");
                editor.commit();
            }

        });

    }





              //  checkdataentered();



    public void again() {
        Intent main = new Intent(signup.this, MainActivity.class);
        startActivity(main);


    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
    void checkdataentered() {






    }

    private boolean isEmail(EditText emaill) {

        CharSequence email = emaill.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());

    }



}
//
 //if (isEmpty(name)) {
   //      Toast t = Toast.makeText(this, "You must enter first name to register!", Toast.LENGTH_SHORT);
       //  name.setError("Enter  Name");
     //    t.show();
        // }
         //if (isEmpty(pass)) {
        // Toast t = Toast.makeText(this, "You must enter Password to register!", Toast.LENGTH_SHORT);
         //pass.setError("Enter  name");
        // t.show();
         //}

         //if (isEmpty(pass)) {
         //name.setError("Enter  Password");

        // }
      //   if (isEmail(email) == false) {
    //     email.setError("Enter valid email!");
  //       }
//