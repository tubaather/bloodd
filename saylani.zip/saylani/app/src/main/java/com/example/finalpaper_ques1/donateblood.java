package com.example.finalpaper_ques1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.jar.Attributes;

public class donateblood extends AppCompatActivity {

    EditText name, assword, mail;
Button btnRegister2;
SharedPreferences sharedPreferences;

private static final String SHARED_PREF_NAME = "DONATE";
private  static final String KEY_NAME = "name";
private static  final String KEY_EMAIL = "email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donateblood);
        name = (EditText) findViewById(R.id.patname);
        assword = (EditText) findViewById(R.id.fathname);
         mail = (EditText) findViewById(R.id.cnic);

        btnRegister2 = (Button) findViewById(R.id.submitform7);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);


        btnRegister2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast =  Toast.makeText(getApplicationContext(),"Your Request Has Been Sent", Toast.LENGTH_SHORT);
                toast.show();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(KEY_NAME,name.getText().toString());
                editor.putString(KEY_EMAIL,assword.getText().toString());
editor.apply();






            }

        });

    }

}

