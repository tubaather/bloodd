package com.example.finalpaper_ques1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class donatebloodrequest extends AppCompatActivity {
    TextView Name,Email;

SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "DONATE";
    private  static final String KEY_NAME = "name";
    private static  final String KEY_EMAIL = "email";
    Button hey;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donatebloodrequest);

        Name = findViewById(R.id.textView7);
        Email = findViewById(R.id.textView8);
        hey = findViewById(R.id.button9);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
        String name = sharedPreferences.getString(KEY_NAME,null);
        String email = sharedPreferences.getString(KEY_EMAIL,null);

        if (name !=null || email != null)
        {
            Name.setText("FULLNAME:"+name);
            Email.setText("EMAIL"+email);
        }

        hey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast =  Toast.makeText(getApplicationContext(),"Request Accepted", Toast.LENGTH_SHORT);
                toast.show();


    }});
}}