package com.example.finalpaper_ques1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class userdash extends AppCompatActivity {
    Button needbloodd;
    Button donatebloodform;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdash);
        SharedPreferences preferences = getSharedPreferences("MYPREFS",MODE_PRIVATE);
        String display = preferences.getString("display","");
        TextView displayinfo = (TextView) findViewById(R.id.textView2);
        displayinfo.setText(display);
        needbloodd = (Button) findViewById(R.id.needbloodd);
        donatebloodform = (Button) findViewById(R.id.donatebloodform);
        needbloodd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity3();
            }
        });
        donatebloodform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity34();
            }
        });
    }

    public void openNewActivity3() {
        Intent intent = new Intent(this, needblood.class);
        startActivity(intent);

    }
    public void openNewActivity34() {
        Intent intent = new Intent(this, donateblood.class);
        startActivity(intent);

    }
}