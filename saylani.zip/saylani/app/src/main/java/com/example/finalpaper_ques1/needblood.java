package com.example.finalpaper_ques1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class needblood extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_needblood);
    }
}