package com.example.finalpaper_ques1;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class login extends AppCompatActivity {

    Button dashlogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
final EditText email = (EditText) findViewById(R.id.email);
        final EditText pass = (EditText) findViewById(R.id.pass);
        dashlogin =(Button) findViewById(R.id.submitform7) ;
        dashlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // String user = name.getText().toString();
                String password = pass.getText().toString();
                String emaill = email.getText().toString();
               // checkdataentered();
                SharedPreferences preferences = getSharedPreferences("MYPREFS",MODE_PRIVATE);
                String userdetails = preferences.getString(  emaill + password + "data", "user name or password is incorrect" );
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("display",  "Hello Member " + userdetails +  " YOU ARE LOGGED IN");
                editor.commit();
             again1();

            }
        });

}

    public void again1() {
        Intent user = new Intent(login.this, userdash.class);
        startActivity(user);


    }

    public void openNewActivity23() {
        Intent intent = new Intent(this, userdash.class);
        startActivity(intent);
    }
}