package com.example.finalpaper_ques1;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    Button button;
    Button loginn;
    Button submitform2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.needbloodd);
        loginn =(Button) findViewById(R.id.submitform7) ;
        submitform2 = (Button) findViewById(R.id.submitform2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
        loginn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity2();
            }
        });
        submitform2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity66();
            }
        });

    }
    public void openNewActivity(){
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }
    public void openNewActivity2(){
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }
    public void openNewActivity66(){
        Intent intent = new Intent(this, admindashboard.class);
        startActivity(intent);
    }

}