package com.example.finalpaper_ques1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class admindashboard extends AppCompatActivity {
    Button button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admindashboard);
        button4 = (Button) findViewById(R.id.button3);

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivitytwo();
            }
        });

    }


    public void openNewActivitytwo() {
        Intent intent = new Intent(this, donatebloodrequest.class);
        startActivity(intent);
    }
}